<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<h2>Dashboard</h2>
<div class="row mt-3">
    <div class="col-md-4">
        <div class="card text-white bg-primary mb-3">
            <div class="card-body">
                <h5 class="card-title">Total Medicamentos</h5>
                <p class="card-text display-6"><?php echo e($totalMedicamentos); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-danger mb-3">
            <div class="card-body">
                <h5 class="card-title">Stock Bajo (&lt;10)</h5>
                <p class="card-text display-6"><?php echo e($stockBajo); ?></p>
            </div>
        </div>
    </div>
</div>
<h4>Medicamentos por Laboratorio</h4>
<table class="table table-striped">
    <thead><tr><th>Laboratorio</th><th>Cantidad</th></tr></thead>
    <tbody>
        <?php $__currentLoopData = $porLaboratorio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr><td><?php echo e($lab->nombre); ?></td><td><?php echo e($lab->medicamentos_count); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\72828\SistemasDistribuidosFQZ\Ejercicios en Clases\web\farmacia\resources\views/dashboard.blade.php ENDPATH**/ ?>