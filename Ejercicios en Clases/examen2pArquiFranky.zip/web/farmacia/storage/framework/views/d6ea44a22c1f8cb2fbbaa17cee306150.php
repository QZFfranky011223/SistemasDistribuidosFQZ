<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmacia - <?php echo $__env->yieldContent('title', 'Sistema'); ?></title>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>"> Farmacia</a>
        <a href="<?php echo e(route('medicamentos.index')); ?>" class="btn btn-outline-light btn-sm">Medicamentos</a>
    </div>
</nav>
<div class="container mt-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\72828\SistemasDistribuidosFQZ\Ejercicios en Clases\web\farmacia\resources\views/layouts/app.blade.php ENDPATH**/ ?>