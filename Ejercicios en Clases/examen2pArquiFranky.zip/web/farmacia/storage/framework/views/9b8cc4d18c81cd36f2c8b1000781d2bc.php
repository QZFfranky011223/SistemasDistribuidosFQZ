<?php $__env->startSection('title', 'Nuevo Medicamento'); ?>
<?php $__env->startSection('content'); ?>
<h2>Nuevo Medicamento</h2>
<form action="<?php echo e(route('medicamentos.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('medicamentos._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <button type="submit" class="btn btn-primary mt-3">Guardar</button>
    <a href="<?php echo e(route('medicamentos.index')); ?>" class="btn btn-secondary mt-3">Cancelar</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\72828\SistemasDistribuidosFQZ\Ejercicios en Clases\web\farmacia\resources\views/medicamentos/create.blade.php ENDPATH**/ ?>