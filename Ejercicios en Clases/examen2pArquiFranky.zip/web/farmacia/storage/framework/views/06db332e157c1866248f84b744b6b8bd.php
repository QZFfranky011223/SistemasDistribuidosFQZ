<?php $__env->startSection('title', 'Medicamentos'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Medicamentos</h2>
    <a href="<?php echo e(route('medicamentos.create')); ?>" class="btn btn-primary">+ Nuevo</a>
</div>
<form method="GET" action="<?php echo e(route('medicamentos.index')); ?>" class="mb-3">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Buscar por nombre comercial o principio activo..." value="<?php echo e(request('search')); ?>">
        <button class="btn btn-outline-secondary" type="submit">Buscar</button>
    </div>
</form>
<table class="table table-striped">
    <thead>
        <tr><th>Nombre Comercial</th><th>Principio Activo</th><th>Presentación</th><th>Precio</th><th>Stock</th><th>Laboratorio</th><th>Acciones</th></tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($med->nombre_comercial); ?></td>
            <td><?php echo e($med->principio_activo); ?></td>
            <td><?php echo e($med->presentacion); ?></td>
            <td>Bs. <?php echo e(number_format($med->precio, 2)); ?></td>
            <td><?php echo e($med->stock); ?></td>
            <td><?php echo e($med->laboratorio->nombre ?? '-'); ?></td>
            <td>
                <a href="<?php echo e(route('medicamentos.edit', $med)); ?>" class="btn btn-sm btn-warning">Editar</a>
                <form action="<?php echo e(route('medicamentos.destroy', $med)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7" class="text-center">No hay medicamentos.</td></tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($medicamentos->appends(request()->query())->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\72828\SistemasDistribuidosFQZ\Ejercicios en Clases\web\farmacia\resources\views/medicamentos/index.blade.php ENDPATH**/ ?>